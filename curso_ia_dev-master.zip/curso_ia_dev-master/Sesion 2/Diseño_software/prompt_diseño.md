

Actua como un arquitecto de software y desarrollador.

Analiza el archivo adjunto y obten las entidades del sistema propuesto 

----------------------

Generar el diagrama ER en formato Mermaid con la información obtenida

----------------------

Genera el diagrama de Casos de uso del sistema propuesto en formato Mermaid

-----------------------

Genera el diagrama de Diagramas de flujo en formato Mermaid

-----------------------

Genera el diagrama de Diagramas de secuencia en formato Mermaid